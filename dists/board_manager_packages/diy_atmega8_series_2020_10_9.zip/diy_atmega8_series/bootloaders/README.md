This folder is used to hold pre-compiled bootloaders. 

The .hex files should not be committed to git.

You can generate the bootloaders using makedist.sh

