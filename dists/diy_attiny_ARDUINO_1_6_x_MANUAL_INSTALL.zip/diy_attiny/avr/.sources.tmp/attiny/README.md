# attiny
ATtiny microcontroller support for the Arduino software (http://arduino.cc). Includes the ATtiny45/85 and the ATtiny44/84.

For Arduino 1.0.x, use the ide-1.0.x branch: https://github.com/damellis/attiny/tree/ide-1.0.x

For Arduino 1.6.x, use the ide-1.6.x branch: https://github.com/damellis/attiny/tree/ide-1.6.x

Tutorial here: http://highlowtech.org/?p=1695
